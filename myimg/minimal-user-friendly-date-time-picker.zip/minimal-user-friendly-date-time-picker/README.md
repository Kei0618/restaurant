# jquery-dateandtime

Manage datetime from input text
display date and time singly

Example to use see index.html
